plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.kelidsim"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.kelidsim"
        minSdk = 26
        targetSdk = 34
        versionCode = 11
        versionName = "11.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
