package com.kelidsim

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast

class LaunchActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (!serviceEnabled()) {
            Toast.makeText(this, getString(R.string.need_access), Toast.LENGTH_LONG).show()
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            finish()
            return
        }

        ClickService.arm()
        if (!openSimSettings()) {
            ClickService.disarm()
            Toast.makeText(this, getString(R.string.cant_open), Toast.LENGTH_LONG).show()
        }
        finish()
    }

    private fun serviceEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.contains(packageName)
    }

    private fun openSimSettings(): Boolean {
        val candidates = listOf(
            Intent().setComponent(
                ComponentName("com.android.settings", "com.android.settings.Settings\$DualCardSettingsActivity")
            ),
            Intent("android.settings.DUAL_SIM_SETTINGS"),
            Intent(Settings.ACTION_NETWORK_OPERATOR_SETTINGS),
            Intent(Settings.ACTION_WIRELESS_SETTINGS)
        )
        for (i in candidates) {
            try {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
                return true
            } catch (e: Exception) {
                // try next
            }
        }
        return false
    }
}
