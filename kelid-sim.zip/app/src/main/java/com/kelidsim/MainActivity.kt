package com.kelidsim

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        refreshStatus()
        findViewById<Button>(R.id.btn_access).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun refreshStatus() {
        val ok = ClickService.instance != null
        findViewById<TextView>(R.id.status).text =
            "نسخهٔ ۸ — سرویس: " + (if (ok) "متصل" else "غیرمتصل")
        findViewById<TextView>(R.id.debug).text = ClickService.debug
    }
}
