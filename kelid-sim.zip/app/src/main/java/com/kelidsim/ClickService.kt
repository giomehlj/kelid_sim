package com.kelidsim

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import android.widget.Toast

class ClickService : AccessibilityService() {

    companion object {
        @Volatile var armedAt = 0L
        @Volatile var phase = 0   // 0: navigate + click SIM switch, 1: confirm dialog, 2: done
        @Volatile var lastNavClick = 0L
        @Volatile var navAttempts = 0
        @Volatile var warned = false
        @Volatile var instance: ClickService? = null
        @Volatile var debug = "هنوز چیزی اجرا نشده"
        @Volatile var steps = 0
        @Volatile var events = 0
        @Volatile var lastError = "-"

        fun arm() {
            phase = 0; lastNavClick = 0L; navAttempts = 0; warned = false
            armedAt = System.currentTimeMillis()
            instance?.startTicker()
        }
        fun disarm() { armedAt = 0L; phase = 2 }

        private val CONFIRM = listOf(
            "تأیید", "تایید", "باشه", "خاموش", "غیرفعال", "بله",
            "ok", "turn off", "disable", "confirm", "yes"
        )
    }

    private val handler = Handler(Looper.getMainLooper())

    private val ticker = object : Runnable {
        override fun run() {
            if (armedAt == 0L) return
            try { step() } catch (e: Throwable) { lastError = e.toString() }
            handler.postDelayed(this, 500)
        }
    }

    fun startTicker() {
        Toast.makeText(this, "کلید سیم: شروع شد", Toast.LENGTH_SHORT).show()
        handler.removeCallbacks(ticker)
        handler.postDelayed(ticker, 800)
    }

    override fun onServiceConnected() { instance = this }
    override fun onDestroy() { instance = null; super.onDestroy() }
    override fun onInterrupt() {}

    private var lastEventStep = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        events++
        if (armedAt == 0L) return
        val now = System.currentTimeMillis()
        if (now - lastEventStep < 300) return
        lastEventStep = now
        try { step() } catch (e: Throwable) { lastError = e.toString() }
    }

    private fun getRoot(): AccessibilityNodeInfo? {
        val r = rootInActiveWindow
        if (r != null && r.packageName != packageName) return r
        try {
            for (w in windows) {
                if (w.type != AccessibilityWindowInfo.TYPE_APPLICATION) continue
                val wr = w.root ?: continue
                if (wr.packageName != packageName) return wr
            }
        } catch (e: Exception) { }
        return null
    }

    private fun warn(now: Long, t: Long, msg: () -> String) {
        if (now - t > 8000 && !warned) {
            warned = true
            Toast.makeText(this, msg(), Toast.LENGTH_LONG).show()
        }
    }

    private fun step() {
        val t = armedAt
        if (t == 0L) return
        val now = System.currentTimeMillis()
        if (now - t > 25000) { disarm(); return }

        steps++
        val root = getRoot()
        if (root == null) {
            debug = "steps=$steps events=$events phase=$phase root=null windows=${try { windows.size } catch (e: Exception) { -1 }} err=$lastError"
            if (phase == 0) warn(now, t) { "کلید سیم: محتوای صفحه خوانده نشد" }
            return
        }

        when (phase) {
            0 -> {
                val onSimPage = has(root, "فرض") || has(root, "default")
                val onNetworkPage = has(root, "هواپیما") || has(root, "airplane")

                if (onSimPage) {
                    val sw = topSwitch(root)
                    if (sw != null && clickNode(sw)) {
                        phase = 1
                        handler.postDelayed({ finishUp() }, 3500)
                        return
                    }
                } else if (onNetworkPage) {
                    if (now - lastNavClick >= 1500) {
                        val rows = find(root, "مدیریتسیم")
                        for (n in rows) {
                            // alternate: normal click, then a real tap on the row
                            val ok = if (navAttempts % 2 == 0) clickNode(n) else tap(n)
                            if (ok) {
                                lastNavClick = now
                                navAttempts++
                                break
                            }
                        }
                    }
                }

                debug = "steps=$steps events=$events phase=$phase pkg=${root.packageName} n=${root.childCount} sim=$onSimPage net=$onNetworkPage rows=${find(root, "مدیریتسیم").size} nav=$navAttempts err=$lastError | ${sampleTexts(root)}"
                warn(now, t) {
                    val head = when {
                        onSimPage -> "صفحهٔ سیم‌کارت پیدا شد ولی کلید پیدا نشد"
                        onNetworkPage -> "ردیف مدیریت سیم‌کارت پیدا یا لمس نشد"
                        else -> "صفحه شناخته نشد"
                    }
                    "کلید سیم: " + head + "\n" + root.packageName + " | " + sampleTexts(root)
                }
            }
            1 -> {
                if (clickConfirm(root)) {
                    phase = 2
                    handler.postDelayed({ finishUp() }, 900)
                }
            }
        }
    }

    private fun finishUp() {
        if (armedAt == 0L && phase == 2) return
        armedAt = 0L
        phase = 2
        performGlobalAction(GLOBAL_ACTION_HOME)
    }

    // ---------- helpers ----------

    // unify Arabic/Persian letter variants, drop ZWNJ, spaces, diacritics
    private fun norm(s: String): String {
        val sb = StringBuilder()
        for (c in s) {
            when {
                c == '\u064a' || c == '\u0649' -> sb.append('\u06cc')
                c == '\u0643' -> sb.append('\u06a9')
                c == '\u200c' || c == '\u200d' || c == '\u200e' || c == '\u200f' -> {}
                c == ' ' || c == '\u00a0' || c == '\u0640' -> {}
                c in '\u064b'..'\u065f' || c == '\u0670' -> {}
                else -> sb.append(c.lowercaseChar())
            }
        }
        return sb.toString()
    }

    private fun sampleTexts(root: AccessibilityNodeInfo): String {
        val out = mutableListOf<String>()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || out.size >= 8) return
            val t = n.text?.toString()?.trim()
            if (!t.isNullOrEmpty()) out.add(t)
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return out.joinToString(" | ")
    }

    private fun nodeText(n: AccessibilityNodeInfo): String =
        norm((n.text?.toString() ?: "") + "|" + (n.contentDescription?.toString() ?: ""))

    private fun find(root: AccessibilityNodeInfo, word: String): List<AccessibilityNodeInfo> {
        val out = mutableListOf<AccessibilityNodeInfo>()
        val w = norm(word)
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            if (nodeText(n).contains(w)) out.add(n)
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return out
    }

    private fun has(root: AccessibilityNodeInfo, word: String) = find(root, word).isNotEmpty()

    private fun collectSwitches(n: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>) {
        if (n == null) return
        val cls = n.className?.toString() ?: ""
        if (cls.contains("Switch") || cls.contains("Toggle")) out.add(n)
        for (i in 0 until n.childCount) collectSwitches(n.getChild(i), out)
    }

    // the switch with the smallest top coordinate = SIM 1 row
    private fun topSwitch(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val list = mutableListOf<AccessibilityNodeInfo>()
        collectSwitches(root, list)
        val r = Rect()
        return list.minByOrNull { it.getBoundsInScreen(r); r.top }
    }

    private fun clickNode(node: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = node
        var depth = 0
        while (n != null && depth < 5) {
            if (n.isClickable && n.isEnabled) {
                if (n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
                break
            }
            n = n.parent
            depth++
        }
        return tap(node)
    }

    private fun tap(n: AccessibilityNodeInfo): Boolean {
        val r = Rect()
        n.getBoundsInScreen(r)
        if (r.width() <= 0 || r.height() <= 0) return false
        val p = Path()
        p.moveTo(r.exactCenterX(), r.exactCenterY())
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 80))
            .build()
        return dispatchGesture(g, null, null)
    }

    private fun clickConfirm(root: AccessibilityNodeInfo): Boolean {
        for (word in CONFIRM) {
            val w = norm(word)
            for (n in find(root, word)) {
                val txt = norm(n.text?.toString() ?: "")
                if (txt == w && clickNode(n)) return true
            }
        }
        return false
    }
}
