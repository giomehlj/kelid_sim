package com.kelidsim

import android.accessibilityservice.AccessibilityService
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class ClickService : AccessibilityService() {

    companion object {
        @Volatile var armedAt = 0L
        @Volatile var phase = 0   // 0: navigate + click SIM switch, 1: look for confirm dialog, 2: done
        @Volatile var lastNavClick = 0L

        fun arm() { phase = 0; lastNavClick = 0L; armedAt = System.currentTimeMillis() }
        fun disarm() { armedAt = 0L; phase = 2 }

        private val CONFIRM = listOf(
            "تأیید", "تایید", "باشه", "خاموش", "غیرفعال", "بله",
            "ok", "turn off", "disable", "confirm", "yes"
        )
    }

    private val handler = Handler(Looper.getMainLooper())

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val t = armedAt
        if (t == 0L) return
        val now = System.currentTimeMillis()
        if (now - t > 25000) { disarm(); return }

        val root = rootInActiveWindow ?: return
        if (root.packageName == packageName) return

        when (phase) {
            0 -> {
                val onSimPage = has(root, "فرض") || has(root, "Default")
                val onNetworkPage = has(root, "هواپیما") || has(root, "Airplane")

                if (onSimPage) {
                    // SIM management page: click the top switch (SIM 1)
                    val sw = topSwitch(root) ?: return
                    if (clickNode(sw)) {
                        phase = 1
                        handler.postDelayed({ finishUp() }, 3500)
                    }
                } else if (onNetworkPage) {
                    // mobile network page: open "مدیریت سیم‌کارت"
                    if (now - lastNavClick < 1500) return
                    val rows = root.findAccessibilityNodeInfosByText("مدیریت سیم")
                    for (n in rows) {
                        if (clickNode(n)) { lastNavClick = now; break }
                    }
                }
            }
            1 -> {
                if (clickConfirm(root)) {
                    phase = 2
                    handler.postDelayed({ finishUp() }, 900)
                }
            }
        }
    }

    private fun has(root: AccessibilityNodeInfo, text: String): Boolean =
        root.findAccessibilityNodeInfosByText(text).isNotEmpty()

    private fun finishUp() {
        if (armedAt == 0L && phase == 2) return
        armedAt = 0L
        phase = 2
        performGlobalAction(GLOBAL_ACTION_HOME)
    }

    private fun collectSwitches(n: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>) {
        if (n == null) return
        val cls = n.className?.toString() ?: ""
        if (n.isVisibleToUser && (cls.contains("Switch") || cls.contains("Toggle"))) out.add(n)
        for (i in 0 until n.childCount) collectSwitches(n.getChild(i), out)
    }

    // the switch with the smallest top coordinate = SIM 1 row
    private fun topSwitch(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val list = mutableListOf<AccessibilityNodeInfo>()
        collectSwitches(root, list)
        val r = Rect()
        return list.minByOrNull { it.getBoundsInScreen(r); r.top }
    }

    private fun clickNode(node: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = node
        var depth = 0
        while (n != null && depth < 5) {
            if (n.isClickable && n.isEnabled) return n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            n = n.parent
            depth++
        }
        return false
    }

    private fun clickConfirm(root: AccessibilityNodeInfo): Boolean {
        for (word in CONFIRM) {
            val found = root.findAccessibilityNodeInfosByText(word)
            for (n in found) {
                val txt = n.text?.toString()?.trim()?.lowercase() ?: continue
                if (txt == word && clickNode(n)) return true
            }
        }
        return false
    }
}
